package gossip;

public class Node implements Runnable {
	private int node_id;
	private FakePipe p;
	private int version;
	
	public Node(int node_id, FakePipe p) {
		this.node_id = node_id+1;
		this.p = p;
		this.version = p.getVersion(node_id);
	}
	
	public void setVersion(int v) {
		this.version = v;
	}
	
	@Override
	public void run() {
		while(true) {
			int randtime = (int)(Math.random()*1000+500);
			int randNerb = (int)(Math.random() * p.neiborNum[node_id-1]);
			//System.out.println("Node: "+node_id+"  "+version);
			try {
				Thread.sleep(randtime);
				if(p.getVersion(p.nerbor[node_id-1][randNerb]) > version)
				{
					version = p.getVersion(p.nerbor[node_id-1][randNerb]);
				}
				p.setVersion(node_id-1, version);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println("Node: "+node_id+" end at "+rand+"ms.");
		}
	}
}