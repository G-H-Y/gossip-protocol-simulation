package gossip;

/*************************
 * 5-1-2
 * |   |
 * 6-3-4
 *  \|  \
 *   7-8-9
 *   
 * total nodes: 9
 * total edges: 11
 ********************/

public class  Gossip{
	public static void main(String[] args) {
		
		FakePipe pipe = new FakePipe();
		Thread tp = new Thread(pipe);
		tp.start();
		
		Node[] nodes = new Node[9]; 
		Thread[] t = new Thread[9];
		Seed d = new Seed(nodes);
		Thread td = new Thread(d);
		td.start();
		
		for(int i=0; i<9; i++)
		{
			nodes[i] = new Node(i, pipe);
			t[i] = new Thread(nodes[i]);
			t[i].start();
		}
		
		try {
			t[0].join();
		} catch (InterruptedException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Process over!");
	}
}