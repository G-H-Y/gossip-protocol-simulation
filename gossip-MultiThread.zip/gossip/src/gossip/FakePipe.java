package gossip;

/*************************
 * 5-1-2
 * |   |
 * 6-3-4
 *  \|  \
 *   7-8-9
 *   
 * total nodes: 9
 * total edges: 11
 ********************/

public class FakePipe implements Runnable {
	
	public int versionList[] = {-1, -1, -1, -1, -1, -1, -1, -1, -1};
	public int neiborNum[] = {2, 2, 3, 3, 2, 3, 3, 2, 2};
	
	public int nerbor[][] = {{1,4}, {0,3}, {3,5,6}, {1,2,8}, {0, 5}, {2, 4, 6}, {2,5,7}, {6,8}, {3,7}};
	
	public FakePipe() {}
	
	public int getVersion(int i){
		return this.versionList[i];
	}
	
	public void setVersion(int i, int v) {
		if(v > this.versionList[i])
			this.versionList[i] = v;
	}
	
	public void printVersion()
	{
		for(int i=0; i<9; i++)
		{
			System.out.println("Version of Node "+ (i+1) +": "+versionList[i]);
		}
		System.out.println();
	}
	
	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(1000);
				printVersion();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}